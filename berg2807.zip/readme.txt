My approach was black-box random guessing, with a smaller range of random values converging on my last best guess.

I started with a large range of random values. Once I had a general guess, I lowered
my range of random values to be closer to around that guess, ultimately converging 
on a pretty good guess. I did this about 3-5 times until I got something I was relatively happy with,
or wasn't seeing much more improvement.